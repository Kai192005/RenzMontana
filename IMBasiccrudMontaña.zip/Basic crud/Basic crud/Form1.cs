﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace Basic_crud
{
    public partial class Form1 : Form
    {
        string connectionString = "server=127.0.0.3;user=root;password=montanarenz.19.05;database=studentinfo;";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        // CREATE
        private void btnCreate_Click(object sender, EventArgs e)
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string query = "INSERT INTO student(studentid, firstName, lastName, Age) VALUES (@studentid, @firstName, @lastName, @Age)";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@studentid", int.Parse(StudentID.Text));
                cmd.Parameters.AddWithValue("@firstName", txtFirstname.Text);
                cmd.Parameters.AddWithValue("@lastName", txtLastName.Text);
                cmd.Parameters.AddWithValue("@Age", int.Parse(txtAge.Text));
                cmd.ExecuteNonQuery();
                MessageBox.Show("Student has been added!");
                LoadData();
            }
        }

        // READ
        private void btnRead_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM student", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridViewStudentdata.DataSource = dt;
            }
        }

        // UPDATE
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string query = "UPDATE student SET firstName=@firstName, lastName=@lastName, Age=@Age WHERE studentid=@studentid";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@studentid", int.Parse(StudentID.Text));
                cmd.Parameters.AddWithValue("@firstName", txtFirstname.Text);
                cmd.Parameters.AddWithValue("@lastName", txtLastName.Text);
                cmd.Parameters.AddWithValue("@Age", int.Parse(txtAge.Text));
                cmd.ExecuteNonQuery();
                MessageBox.Show("Student updated!");
                LoadData();
            }
        }

        // DELETE
        private void btnDelete_Click(object sender, EventArgs e)
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string query = "DELETE FROM student WHERE studentid=@studentid";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@studentid", int.Parse(StudentID.Text));
                cmd.ExecuteNonQuery();
                MessageBox.Show("Student deleted!");
                LoadData();
            }
        }

       
       

        private void dataGridViewStudentdata_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewStudentdata.Rows[e.RowIndex];
                StudentID.Text = row.Cells["studentid"].Value.ToString();
                txtFirstname.Text = row.Cells["firstName"].Value.ToString();
                txtLastName.Text = row.Cells["lastName"].Value.ToString();
                txtAge.Text = row.Cells["Age"].Value.ToString();
            }
        }
    }
}